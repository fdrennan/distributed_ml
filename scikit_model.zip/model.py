# source activate distributed
# conda env export > distributed.yml
from sklearn import linear_model
from sklearn.externals import joblib
import sys
sys.path.insert(0, '../')
import distributed_ml as dml
import shutil

reg = linear_model.LinearRegression()
reg.fit([[0, 0], [1, 1], [2, 2]], [0, 1, 2])

reg.coef_

joblib.dump(reg, 'regression.joblib')

clf = joblib.load('regression.joblib')

clf.coef_

D = dml.Distributor(server = True)

D.upload_file()